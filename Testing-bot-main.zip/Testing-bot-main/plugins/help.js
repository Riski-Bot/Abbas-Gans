const help = (prefix) => { 
	return `                 
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━⊱
┃
┃➸ *${prefix}apakah*
┃➸ *${prefix}apakah2*
┃➸ *${prefix}fitnah*
┃➸ *${prefix}kapan*
┃➸ *${prefix}kapankah*
┃➸ *${prefix}bucin*
┃➸ *${prefix}profile*
┃➸ *${prefix}speed*
┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┃➸ *${prefix}stiker*
┃➸ *${prefix}tahta* [teks]
┃➸ *${prefix}stiker* [caption]
┃➸ *${prefix}toimg*
┃➸ *${prefix}ttp*
┃➸ *${prefix}attp* [teks]
┃➸ *${prefix}simi* [teks]
┃➸ *${prefix}simisimi*
┃➸ *${prefix}simih* [teks]
┃➸ *${prefix}base64*
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┃➸ *${prefix}caculator*
┃➸ *${prefix}halah*
┃➸ *${prefix}hilih*
┃➸ *${prefix}huluh*
┃➸ *${prefix}heleh*
┃➸ *${prefix}holoh*
┃➸ *${prefix}mention*
┃➸ *${prefix}nulis*
┃➸ *${prefix}qr*
┃➸ *${prefix}kodeqr*
┃➸ *${prefix}readmore* [teks]²
┃➸ *${prefix}spoiler* [teks]²
┃
┣━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━⊱
┃
┃➸ *${prefix}run* [limit]
┃➸ *${prefix}ping*
┃➸ *${prefix}stile* [teks]
┃➸ *${prefix}tekspro* [efek+teks]
┃➸ *${prefix}tts* [lang+teks]
┃➸ *${prefix}menu*
┃➸ *${prefix}help*
┃➸ *${prefix}fetch* [url]
┃➸ *${prefix}get* [url]
┃➸ *${prefix}geogle*
┃➸ *${prefix}Ss* [url]
┃➸ *${prefix}ssf* [link]
┃➸ *${prefix} *
┃
┣━━━━°❀ ❬ 𝗠𝗘𝗡𝗨 𝗕𝗢𝗧 ❭ ❀°━━━━⊱
┃
┃➸ *${prefix}jadibot* [limit]
┃➸ *${prefix}getcode* [codebot]
┃➸ *${prefix}berhenti*
┃➸ *${prefix}broadcastjadibot*
┃➸ *${prefix}bcbot* [teks]
┃➸ *${prefix}debauce*
┃➸ *${prefix}update* [menu]
┃
┣━━━━°❀ ❬ 𝗜𝗡𝗙𝗢 𝗕𝗢𝗧 ❭ ❀°━━━━⊱
┃
┃➸ *${prefix}owner*
┃➸ *${prefix}creator*
┃➸ *${prefix}del*
┃➸ *${prefix}delete*
┃➸ *${prefix}donasi*
┃➸ *${prefix}groups*
┃➸ *${prefix}grouplist*
┃➸ *${prefix}ping*
┃➸ *${prefix}speed*  
┃
┣━━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━⊱
┃
┃➸ *${prefix}banchat*
┃➸ *${prefix}broadcast* [teks]
┃➸ *${prefix}bc* [teks]
┃➸ *${prefix}broadcas* [group]
┃➸ *${prefix}bcgc* [teks]
┃➸ *${prefix}deletechat*
┃➸ *${prefix}deletechat* [group]
┃➸ *${prefix}mutechat*
┃➸ *${prefix}mutechat* [group]
┃➸ *${prefix}eneble* [option]
┃➸ *${prefix}disabele* [option]
┃➸ *${prefix}oadd* [@user]
┃➸ *${prefix}o+* [user]
┃➸ *${prefix}odemote* [user]
┃➸ *${prefix}omember* [@user]
┃➸ *${prefix}ov* [@user]
┃➸ *${prefix}okick* [@user]
┃➸ *${prefix}o-* [@user]
┃➸ *${prefix}pengunguman* [teks]
┃➸ *${prefix}ohidetag* [teks]
┃➸ *${prefix}opromote* [@user]
┃➸ *${prefix}oadmin* [@user]
┃➸ *${prefix}o^* [@user]
┃➸ *${prefix}setbye* [teks]
┃➸ *${prefix}setmenu* [teks]
┃➸ *${prefix}setmenubefore*
┃➸ *${prefix}setmenuheader*
┃➸ *${prefix}setmenubody*
┃➸ *${prefix}setmenufooter*
┃➸ *${prefix}setmenuafter*
┃➸ *${prefix}setwelcome* [teks]
┃➸ *${prefix}unbanechat*
┣━━━━°❀ ❬ 𝗠𝗘𝗡𝗨 🔞+ ❭ ❀°━━━━⊱
┃
┃➸ *${prefix}xnxx*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃     *Abbas Gans *
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help



  
